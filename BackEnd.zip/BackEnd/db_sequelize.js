const { Sequelize, Model, DataTypes } = require('sequelize');
const sequelize = new Sequelize('mysql://admin25:Password.@db-2076223-2077723.mysql.database.azure.com:3306/cloneolx      ')